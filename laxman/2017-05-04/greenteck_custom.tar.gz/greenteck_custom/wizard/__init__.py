import bulk
